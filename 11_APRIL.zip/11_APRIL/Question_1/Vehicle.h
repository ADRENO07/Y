#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>
using namespace std;

class Vehicle {
protected:
    string type;
    string model;
    string fuelType;
    int noOfWheels;
    string brand;

public:
   
    Vehicle(string type, string model, string fuelType, int noOfWheels, string brand);
    
  
    virtual ~Vehicle();
    
    
    virtual void display();
};

#endif
