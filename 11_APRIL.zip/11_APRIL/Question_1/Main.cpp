#include <iostream>
#include "Car.h"
#include "Auto.h"
#include "Bike.h"

using namespace std;

int main() {
    Vehicle* vPtr = nullptr;
    int choice;

    do {
        cout << "\nVehicle Management System" << endl;
        cout << "1. Create a Car" << endl;
        cout << "2. Create an Auto" << endl;
        cout << "3. Create a Bike" << endl;
        cout << "4. Display Vehicle Details & Run Specific Method (RTTI)" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                if (vPtr) delete vPtr; 
                string model, fuel, brand, category;
                cout << "Enter Model: "; cin >> model;
                cout << "Enter Fuel Type: "; cin >> fuel;
                cout << "Enter Brand: "; cin >> brand;
                cout << "Enter Category (Sedan/SUV/Hatchback): "; cin >> category;
                vPtr = new Car(model, fuel, brand, category);
                cout << "Car created successfully!" << endl;
                break;
            }
            case 2: {
                if (vPtr) delete vPtr;
                string model, fuel, brand;
                int seats;
                cout << "Enter Model: "; cin >> model;
                cout << "Enter Fuel Type: "; cin >> fuel;
                cout << "Enter Brand: "; cin >> brand;
                cout << "Enter Number of Seats: "; cin >> seats;
                vPtr = new Auto(model, fuel, brand, seats);
                cout << "Auto created successfully!" << endl;
                break;
            }
            case 3: {
                if (vPtr) delete vPtr;
                string model, fuel, brand, bType;
                cout << "Enter Model: "; cin >> model;
                cout << "Enter Fuel Type: "; cin >> fuel;
                cout << "Enter Brand: "; cin >> brand;
                cout << "Enter Bike Type (Sports/Cruiser/Commuter): "; cin >> bType;
                vPtr = new Bike(model, fuel, brand, bType);
                cout << "Bike created successfully!" << endl;
                break;
            }
            case 4: {
                if (!vPtr) {
                    cout << "No vehicle created yet! Please create a vehicle first." << endl;
                    break;
                }

                
                vPtr->display();

                cout << "\nRTTI Downcasting Check" << endl;
                
                
                Car* carPtr = dynamic_cast<Car*>(vPtr);
                if (carPtr != nullptr) {
                    carPtr->carSpecificMethod();
                }

                
                Auto* autoPtr = dynamic_cast<Auto*>(vPtr);
                if (autoPtr != nullptr) {
                    autoPtr->autoSpecificMethod();
                }

             
                Bike* bikePtr = dynamic_cast<Bike*>(vPtr);
                if (bikePtr != nullptr) {
                    bikePtr->bikeSpecificMethod();
                }
                break;
            }
            case 5:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 5);

   
    if (vPtr) {
        delete vPtr;
    }

    return 0;
}
