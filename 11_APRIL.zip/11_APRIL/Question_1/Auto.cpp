#include "Auto.h"
#include <iostream>

Auto::Auto(string model, string fuelType, string brand, int seats) 
    : Vehicle("Auto", model, fuelType, 3, brand), seats(seats) {}

void Auto::display() {
    Vehicle::display();
    cout << "Seats: " << seats << endl;
}

void Auto::autoSpecificMethod() {
    cout << "[Auto Specific] This auto has a seating capacity of " << seats << " passengers." << endl;
}
