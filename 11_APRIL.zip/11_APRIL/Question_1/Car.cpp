#include "Car.h"
#include <iostream>

Car::Car(string model, string fuelType, string brand, string category) 
    : Vehicle("Car", model, fuelType, 4, brand), category(category) {}

void Car::display() {
    Vehicle::display();
    cout << "Category: " << category << endl;
}

void Car::carSpecificMethod() {
    cout << "[Car Specific] This car belongs to the " << category << " category." << endl;
}
