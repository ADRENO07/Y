#ifndef BIKE_H
#define BIKE_H

#include "Vehicle.h"

class Bike : public Vehicle {
private:
    string bikeType;

public:
    Bike(string model, string fuelType, string brand, string bikeType);
    
    void display() override;
    
   
    void bikeSpecificMethod();
};

#endif
