#ifndef AUTO_H
#define AUTO_H

#include "Vehicle.h"

class Auto : public Vehicle {
private:
    int seats;

public:
    Auto(string model, string fuelType, string brand, int seats);
    
    void display() override;
    
    
    void autoSpecificMethod();
};

#endif
