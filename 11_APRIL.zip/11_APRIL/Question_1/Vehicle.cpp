#include "Vehicle.h"
#include <iostream>

Vehicle::Vehicle(string type, string model, string fuelType, int noOfWheels, string brand) 
    : type(type), model(model), fuelType(fuelType), noOfWheels(noOfWheels), brand(brand) {}

Vehicle::~Vehicle() {}

void Vehicle::display() {
    cout << "\nVehicle Details" << endl;
    cout << "Type: " << type << endl;
    cout << "Model: " << model << endl;
    cout << "Fuel Type: " << fuelType << endl;
    cout << "Number of Wheels: " << noOfWheels << endl;
    cout << "Brand: " << brand << endl;
}
