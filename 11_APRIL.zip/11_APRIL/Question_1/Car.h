#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"

class Car : public Vehicle {
private:
    string category;

public:
    Car(string model, string fuelType, string brand, string category);
    
    void display() override;
    
    
    void carSpecificMethod();
};

#endif
