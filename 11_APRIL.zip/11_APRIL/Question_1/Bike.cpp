#include "Bike.h"
#include <iostream>

Bike::Bike(string model, string fuelType, string brand, string bikeType) 
    : Vehicle("Bike", model, fuelType, 2, brand), bikeType(bikeType) {}

void Bike::display() {
    Vehicle::display();
    cout << "Bike Type: " << bikeType << endl;
}

void Bike::bikeSpecificMethod() {
    cout << "[Bike Specific] This is a " << bikeType << " bike." << endl;
}
