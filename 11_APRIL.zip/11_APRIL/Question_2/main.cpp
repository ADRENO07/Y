#include "main.h"


int square(int x) {
    return x * x;
}


void demonstrateVector() {
    std::cout << "std::vector Demonstration" << std::endl;
    
    
    std::vector<int> vec = {10, 20, 30, 40, 50};
    
   
    vec.push_back(60);       
    vec.insert(vec.begin(), 5); 
    
    
    std::cout << "Element at index 2: " << vec[2] << std::endl;
    std::cout << "First element: " << vec.front() << ", Last element: " << vec.back() << std::endl;
    
    
    vec.pop_back();          
    vec.erase(vec.begin());  
    
    std::cout << "Vector after modifications: ";
    for (int v : vec) {
        std::cout << v << " ";
    }
    std::cout << "\nSize of vector: " << vec.size() << "\n" << std::endl;
}


void demonstrateList() {
    std::cout << "std::list Demonstration" << std::endl;
    
    
    std::list<std::string> names = {"Alice", "Charlie", "Eve"};
    
    
    names.push_back("Frank");
    names.push_front("Bob");
    

    names.remove("Eve"); 
    
    
    names.sort();
    
    std::cout << "Sorted List: ";
    for (const std::string& name : names) {
        std::cout << name << " ";
    }
    
    
    names.reverse();
    std::cout << "\nReversed List: ";
    for (const std::string& name : names) {
        std::cout << name << " ";
    }
    std::cout << "\nSize of list: " << names.size() << "\n" << std::endl;
}


void demonstrateAlgorithms() {
    std::cout << "STL Algorithms Demonstration" << std::endl;
    
    std::vector<int> data = {5, 2, 9, 1, 9, 6, 3};
    
    
    std::sort(data.begin(), data.end());
    std::cout << "Sorted (Ascending): ";
    for (int d : data) std::cout << d << " ";
    
    
    std::sort(data.begin(), data.end(), std::greater<int>());
    std::cout << "\nSorted (Descending): ";
    for (int d : data) std::cout << d << " ";
    
    
    int countOf9 = std::count(data.begin(), data.end(), 9);
    std::cout << "\nCount of '9': " << countOf9;
    
    
    auto it = std::find(data.begin(), data.end(), 6);
    if (it != data.end()) {
        std::cout << "\nFound '6' at index: " << std::distance(data.begin(), it);
    }
    
    
    std::vector<int> squaredData(data.size());
    std::transform(data.begin(), data.end(), squaredData.begin(), square);
    std::cout << "\nSquared elements: ";
    for (int d : squaredData) std::cout << d << " ";
    
    
    int sum = std::accumulate(data.begin(), data.end(), 0);
    std::cout << "\nSum of elements: " << sum << "\n" << std::endl;
}

int main() {
    demonstrateVector();
    demonstrateList();
    demonstrateAlgorithms();
    
    return 0;
}
