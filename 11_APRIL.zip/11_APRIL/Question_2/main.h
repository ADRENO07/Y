#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include <numeric>   
#include <string>


void demonstrateVector();
void demonstrateList();
void demonstrateAlgorithms();


int square(int x);

#endif 
