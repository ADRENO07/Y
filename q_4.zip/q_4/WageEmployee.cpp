#include "WageEmployee.h"
#include <sstream>
#include <stdexcept>

WageEmployee::WageEmployee(int id_, std::string name_, double hourlyRate_, double hoursWorked_)
    : Employee(id_, std::move(name_)), hourlyRate(hourlyRate_), hoursWorked(hoursWorked_) {}

double WageEmployee::getHourlyRate() const { return hourlyRate; }
double WageEmployee::getHoursWorked() const { return hoursWorked; }
double WageEmployee::grossPay() const { return hourlyRate * hoursWorked; }

std::string WageEmployee::typeName() const { return "WageEmployee"; }

void WageEmployee::print(std::ostream& os) const {
    Employee::print(os);
    os << ", Type: " << typeName()
       << ", HourlyRate: " << hourlyRate
       << ", HoursWorked: " << hoursWorked
       << ", GrossPay: " << grossPay();
}

std::string WageEmployee::serialize() const {
    // CSV: WageEmployee,id,name,hourlyRate,hoursWorked
    std::ostringstream oss;
    oss << typeName() << ',' << id << ',';

    // Escape commas in name by replacing with semicolon (simple approach)
    std::string safeName = name;
    for (char& c : safeName) if (c == ',') c = ';';

    oss << safeName << ',' << hourlyRate << ',' << hoursWorked;
    return oss.str();
}

WageEmployee WageEmployee::deserialize(const std::string& line) {
    std::istringstream iss(line);
    std::string token;

    // type
    if (!std::getline(iss, token, ',')) throw std::runtime_error("Bad line: missing type");
    std::string type = token;

    if (type != "WageEmployee") throw std::runtime_error("Unsupported type: " + type);

    // id
    if (!std::getline(iss, token, ',')) throw std::runtime_error("Bad line: missing id");
    int id = std::stoi(token);

    // name
    if (!std::getline(iss, token, ',')) throw std::runtime_error("Bad line: missing name");
    std::string name = token;
    for (char& c : name) if (c == ';') c = ','; // unescape

    // hourlyRate
    if (!std::getline(iss, token, ',')) throw std::runtime_error("Bad line: missing hourlyRate");
    double hourlyRate = std::stod(token);

    // hoursWorked
    if (!std::getline(iss, token, ',')) throw std::runtime_error("Bad line: missing hoursWorked");
    double hoursWorked = std::stod(token);

    return WageEmployee(id, name, hourlyRate, hoursWorked);
}

