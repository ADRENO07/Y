#ifndef WAGEEMPLOYEE_H
#define WAGEEMPLOYEE_H

#include "Employee.h"
#include <string>
#include <ostream>
#include <istream>

class WageEmployee : public Employee {
public:
    WageEmployee() = default;
    WageEmployee(int id, std::string name, double hourlyRate, double hoursWorked);

    double getHourlyRate() const;
    double getHoursWorked() const;
    double grossPay() const;

    std::string typeName() const override;
    void print(std::ostream& os) const override;

    // Serialization helpers (text CSV)
    std::string serialize() const;
    static WageEmployee deserialize(const std::string& line);

private:
    double hourlyRate{0.0};
    double hoursWorked{0.0};
};

#endif // WAGEEMPLOYEE_H

