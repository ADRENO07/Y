#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include <iostream>

class Employee {
public:
    Employee() = default;
    Employee(int id, std::string name);
    virtual ~Employee() = default;

    int getId() const;
    const std::string& getName() const;

    virtual std::string typeName() const = 0;
    virtual void print(std::ostream& os) const;

protected:
    int id{0};
    std::string name;
};

#endif // EMPLOYEE_H

