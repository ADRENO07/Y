#include "WageEmployee.h"
#include <vector>
#include <fstream>
#include <iostream>
#include <string>

// Save a vector of WageEmployee to a text file (one CSV line per employee)
void saveEmployees(const std::string& filename, const std::vector<WageEmployee>& employees) {
    std::ofstream ofs(filename);
    if (!ofs) {
        throw std::runtime_error("Cannot open file for writing: " + filename);
    }
    for (const auto& e : employees) {
        ofs << e.serialize() << '\n';
    }
}

// Load WageEmployee objects from a file
std::vector<WageEmployee> loadEmployees(const std::string& filename) {
    std::vector<WageEmployee> result;
    std::ifstream ifs(filename);
    if (!ifs) {
        // If file doesn't exist, return empty vector
        return result;
    }
    std::string line;
    while (std::getline(ifs, line)) {
        if (line.empty()) continue;
        try {
            result.push_back(WageEmployee::deserialize(line));
        } catch (const std::exception& ex) {
            std::cerr << "Skipping bad line: " << ex.what() << '\n';
        }
    }
    return result;
}

int main() {
    const std::string filename = "employees.txt";

    // Create some sample employees
    std::vector<WageEmployee> employees{
        WageEmployee(1, "Alice Johnson", 25.0, 40.0),
        WageEmployee(2, "Bob, Jr", 18.5, 35.5), // name contains comma to demonstrate escaping
        WageEmployee(3, "Charlie", 30.0, 20.0)
    };

    try {
        // Save to file
        saveEmployees(filename, employees);
        std::cout << "Saved " << employees.size() << " employees to " << filename << '\n';

        // Clear and reload
        employees.clear();
        auto loaded = loadEmployees(filename);
        std::cout << "Loaded " << loaded.size() << " employees from " << filename << '\n';

        // Display loaded employees
        for (const auto& e : loaded) {
            e.print(std::cout);
            std::cout << '\n';
        }
    } catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << '\n';
        return 1;
    }

    return 0;
}

