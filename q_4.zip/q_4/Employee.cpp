#include "Employee.h"

Employee::Employee(int id_, std::string name_)
    : id(id_), name(std::move(name_)) {}

int Employee::getId() const { return id; }
const std::string& Employee::getName() const { return name; }

void Employee::print(std::ostream& os) const {
    os << "ID: " << id << ", Name: " << name;
}

