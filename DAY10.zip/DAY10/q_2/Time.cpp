#include "Time.h"
#include <iostream>
using namespace std;

Time::Time(int h, int m) {
    if (h<0 || h>23 || m<0 || m>59) throw h;
    hour=h; minute=m;
}

void Time::display() const {
    cout << (hour<10?"0":"") << hour << ":" << (minute<10?"0":"") << minute << endl;
}

Time Time::operator+(const Time& t) const {
    int total = hour*60+minute + t.hour*60+t.minute;
    return Time((total/60)%24, total%60);
}

Time Time::operator-(const Time& t) const {
    int total = hour*60+minute - (t.hour*60+t.minute);
    if (total<0) throw total;
    return Time((total/60)%24, total%60);
}

Time& Time::operator++() {
    minute++;
    if (minute==60){ minute=0; hour=(hour+1)%24; }
    return *this;
}

Time& Time::operator--() {
    if (hour==0 && minute==0) throw hour;
    minute--;
    if (minute<0){ minute=59; hour--; }
    return *this;
}

