#include "Time.h"
#include <iostream>
using namespace std;

int main() {
    try {
        Time t1(10,30), t2(2,45);
        int choice;
        do {
            cout << "\nMenu:\n1.Add\n2.Subtract\n3.Increment\n4.Decrement\n5.Exit\nChoice:";
            cin >> choice;
            switch(choice){
                case 1: (t1+t2).display(); break;
                case 2: (t1-t2).display(); break;
                case 3: (++t1).display(); break;
                case 4: (--t1).display(); break;
            }
        } while(choice!=5);
    }
    catch(int ex){
        cout << "Exception: Invalid time operation" << endl;
    }
    return 0;
}

