#ifndef TIME_H
#define TIME_H

class Time {
    int hour, minute;
public:
    Time(int h=0, int m=0);
    void display() const;
    Time operator+(const Time& t) const;
    Time operator-(const Time& t) const;
    Time& operator++(); // increment
    Time& operator--(); // decrement
};

#endif

