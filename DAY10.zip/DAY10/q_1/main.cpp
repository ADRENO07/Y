#include "Employee.h"
#include <iostream>
using namespace std;

int main() {
    try {
        Employee e1(-1,"John",5000);
        e1.display();
    }
    catch (int ex) {
        cout << "Exception: Negative ID" << endl;
    }
    catch (char ex) {
        cout << "Exception: Invalid Name" << endl;
    }
    catch (double ex) {
        cout << "Exception: Negative Salary" << endl;
    }
    return 0;
}

