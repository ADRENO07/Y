#ifndef EMPLOYEE_H
#define EMPLOYEE_H

class Employee {
    int id;
    char ename[50];
    double salary;
    bool hasSpecialChars(const char* s);

public:
    Employee(int i, const char* n, double s);
    void display() const;
};

#endif

