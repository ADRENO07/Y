#include "Employee.h"
#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;

bool Employee::hasSpecialChars(const char* s) {
    for (int i=0; s[i]!='\0'; i++) {
        if (!isalpha(s[i]) && !isspace(s[i])) return true;
    }
    return false;
}

Employee::Employee(int i, const char* n, double s) {
    if (i < 0) throw i;
    if (strlen(n)==0 || hasSpecialChars(n)) throw 'N';
    if (s < 0) throw s;

    id = i;
    strcpy(ename,n);
    salary = s;
}

void Employee::display() const {
    cout << "ID: " << id << ", Name: " << ename << ", Salary: " << salary << endl;
}

