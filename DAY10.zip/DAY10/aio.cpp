#include <iostream>
#include <cstring>
#include <cctype>
#include <cstdio>
using namespace std;

// ---------------- Employee ----------------
class Employee {
    int id;
    char ename[50];
    double salary;
    bool hasSpecialChars(const char* s) {
        for (int i=0; s[i]!='\0'; i++) {
            if (!isalpha(s[i]) && !isspace(s[i])) return true;
        }
        return false;
    }
public:
    Employee(int i, const char* n, double s) {
        if (i < 0) throw i;
        if (strlen(n)==0 || hasSpecialChars(n)) throw 'N';
        if (s < 0) throw s;
        id = i;
        strcpy(ename,n);
        salary = s;
    }
    void display() const {
        cout << "ID: " << id << ", Name: " << ename << ", Salary: " << salary << endl;
    }
};

// ---------------- Time ----------------
class Time {
    int hour, minute;
public:
    Time(int h=0, int m=0) {
        if (h<0 || h>23 || m<0 || m>59) throw h;
        hour=h; minute=m;
    }
    void display() const {
        cout << (hour<10?"0":"") << hour << ":" << (minute<10?"0":"") << minute << endl;
    }
    Time operator+(const Time& t) const {
        int total = hour*60+minute + t.hour*60+t.minute;
        return Time((total/60)%24, total%60);
    }
    Time operator-(const Time& t) const {
        int total = hour*60+minute - (t.hour*60+t.minute);
        if (total<0) throw total;
        return Time((total/60)%24, total%60);
    }
    Time& operator++() {
        minute++;
        if (minute==60){ minute=0; hour=(hour+1)%24; }
        return *this;
    }
    Time& operator--() {
        if (hour==0 && minute==0) throw hour;
        minute--;
        if (minute<0){ minute=59; hour--; }
        return *this;
    }
};

// ---------------- Date ----------------
class Date {
    int day, month, year;
public:
    Date(int d=1,int m=1,int y=2000){
        if(d<=0||d>31||m<=0||m>12||y<=0) throw d;
        day=d; month=m; year=y;
    }
    void display() const {
        cout << day << "/" << month << "/" << year << endl;
    }
    friend void writeDateToFile(const Date& d);
    friend Date readDateFromFile();
};

// Define the friend functions outside the class
void writeDateToFile(const Date& d){
    FILE* f = fopen("date.csv","w");
    if(!f) throw 'F';
    fprintf(f,"%d,%d,%d",d.day,d.month,d.year);
    fclose(f);
}

Date readDateFromFile(){
    FILE* f = fopen("date.csv","r");
    if(!f) throw 'F';
    int d,m,y;
    fscanf(f,"%d,%d,%d",&d,&m,&y);
    fclose(f);
    return Date(d,m,y);
}


// ---------------- Main Menu ----------------
int main(){
    int choice;
    do {
        cout << "\nMain Menu:\n1.Employee\n2.Time\n3.Date\n4.Exit\nChoice: ";
        cin >> choice;
        try {
            if(choice==1){
                int id; char name[50]; double sal;
                cout << "Enter ID, Name, Salary: ";
                cin >> id >> name >> sal;
                Employee e(id,name,sal);
                e.display();
            }
            else if(choice==2){
                Time t1(10,30), t2(2,45);
                int op;
                cout << "\nTime Menu:\n1.Add\n2.Subtract\n3.Increment\n4.Decrement\nChoice: ";
                cin >> op;
                switch(op){
                    case 1: (t1+t2).display(); break;
                    case 2: (t1-t2).display(); break;
                    case 3: (++t1).display(); break;
                    case 4: (--t1).display(); break;
                }
            }
            else if(choice==3){
                Date d1(10,4,2026);
                writeDateToFile(d1);
                Date d2 = readDateFromFile();
                cout << "Read from file: "; d2.display();
            }
        }
        catch(int ex){ cout << "Exception: Invalid numeric input" << endl; }
        catch(char ex){ cout << "Exception: Invalid name or file error" << endl; }
        catch(double ex){ cout << "Exception: Invalid salary" << endl; }
    } while(choice!=4);

    return 0;
}

