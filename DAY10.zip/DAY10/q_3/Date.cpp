#include "Date.h"
#include <iostream>
#include <cstdio>
using namespace std;

Date::Date(int d,int m,int y){
    if(d<=0||d>31||m<=0||m>12||y<=0) throw d;
    day=d; month=m; year=y;
}

void Date::display() const {
    cout << day << "/" << month << "/" << year << endl;
}

void writeDateToFile(const Date& d){
    FILE* f = fopen("date.csv","w");
    if(!f) throw 'F';
    fprintf(f,"%d,%d,%d",d.day,d.month,d.year);
    fclose(f);
}

Date readDateFromFile(){
    FILE* f = fopen("date.csv","r");
    if(!f) throw 'F';
    int d,m,y;
    fscanf(f,"%d,%d,%d",&d,&m,&y);
    fclose(f);
    return Date(d,m,y);
}

