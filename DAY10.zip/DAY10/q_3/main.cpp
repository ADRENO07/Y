#include "Date.h"
#include <iostream>
using namespace std;

int main(){
    try{
        Date d1(10,4,2026);
        writeDateToFile(d1);
        Date d2 = readDateFromFile();
        cout << "Read from file: "; d2.display();
    }
    catch(int ex){
        cout << "Exception: Invalid date" << endl;
    }
    catch(char ex){
        cout << "Exception: File error" << endl;
    }
    return 0;
}

