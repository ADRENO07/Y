#ifndef DATE_H
#define DATE_H

class Date {
    int day, month, year;
public:
    Date(int d=1,int m=1,int y=2000);
    void display() const;
    friend void writeDateToFile(const Date& d);
    friend Date readDateFromFile();
};

// Explicit non-member declarations so callers (like main.cpp) see them
void writeDateToFile(const Date& d);
Date readDateFromFile();

#endif // DATE_H

