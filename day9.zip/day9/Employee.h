#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    double basic;
public:
    Employee(string n, double b);
    virtual void calSalary();
    virtual ~Employee();
};

class Manager : public Employee {
    double allowance;
public:
    Manager(string n, double b, double a);
    void calSalary() override;
    void Bonus();
};

class Developer : public Employee {
    double overtime;
public:
    Developer(string n, double b, double ot);
    void calSalary() override;
};

#endif
