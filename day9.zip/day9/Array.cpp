#include "Array.h"

Array::Array(int s) {
    size = s;
    arr = (size > 0) ? new int[size] : nullptr;
}

Array::Array(const Array& obj) {
    size = obj.size;
    arr = new int[size];
    for (int i = 0; i < size; i++) arr[i] = obj.arr[i];
}

Array& Array::operator=(const Array& obj) {
    if (this == &obj) return *this;
    delete[] arr;
    size = obj.size;
    arr = new int[size];
    for (int i = 0; i < size; i++) arr[i] = obj.arr[i];
    return *this;
}

Array Array::operator+(const Array& obj) {
    Array temp(size);
    for (int i = 0; i < size; i++) temp.arr[i] = arr[i] + obj.arr[i];
    return temp;
}

int& Array::operator[](int index) { return arr[index]; }

bool Array::operator==(const Array& obj) {
    if (size != obj.size) return false;
    for (int i = 0; i < size; i++) {
        if (arr[i] != obj.arr[i]) return false;
    }
    return true;
}

void Array::input() {
    for (int i = 0; i < size; i++) cin >> arr[i];
}

void Array::display() const {
    for (int i = 0; i < size; i++) cout << arr[i] << " ";
    cout << endl;
}

Array::~Array() { delete[] arr; }
