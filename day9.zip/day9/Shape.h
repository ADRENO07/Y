#ifndef SHAPE_H
#define SHAPE_H
#include <iostream>
#include <cmath>
using namespace std;

class Shape {
public:
    virtual void area() = 0;
    virtual void perimeter() = 0;
    virtual ~Shape() {}
};

class Circle : public Shape {
    double r;
public:
    Circle(double radius);
    void area() override;
    void perimeter() override;
    void circumference();
};

class Square : public Shape {
    double side;
public:
    Square(double s);
    void area() override;
    void perimeter() override;
};

class Triangle : public Shape {
    double a, b, c;
public:
    Triangle(double x, double y, double z);
    void area() override;
    void perimeter() override;
};

#endif
