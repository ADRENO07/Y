#ifndef ARRAY_H
#define ARRAY_H
#include <iostream>
using namespace std;

class Array {
    int size;
    int* arr;
public:
    Array(int s = 0);
    Array(const Array& obj);
    Array& operator=(const Array& obj);
    Array operator+(const Array& obj);
    int& operator[](int index);
    bool operator==(const Array& obj);
    void input();
    void display() const;
    ~Array();
};

#endif
