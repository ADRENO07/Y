#ifndef DIAMOND_H
#define DIAMOND_H
#include <iostream>
using namespace std;

class A {
protected:
    int a;
public:
    A(int x);
};

class B : virtual public A {
protected:
    int b;
public:
    B(int x, int y);
};

class C : virtual public A {
protected:
    int c;
public:
    C(int x, int z);
};

class D : public B, public C {
public:
    D(int x, int y, int z);
    void display();
};

#endif
