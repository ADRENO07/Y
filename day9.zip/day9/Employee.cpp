#include "Employee.h"

Employee::Employee(string n, double b) : name(n), basic(b) {}
void Employee::calSalary() {
    cout << "Employee Salary: " << basic << endl;
}
Employee::~Employee() {}

Manager::Manager(string n, double b, double a) : Employee(n, b), allowance(a) {}
void Manager::calSalary() {
    cout << "Manager Salary: " << basic + allowance << endl;
}
void Manager::Bonus() {
    cout << "Manager Bonus: " << allowance * 0.5 << endl;
}

Developer::Developer(string n, double b, double ot) : Employee(n, b), overtime(ot) {}
void Developer::calSalary() {
    cout << "Developer Salary: " << basic + overtime << endl;
}
