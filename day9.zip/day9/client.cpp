#include "Employee.h"
#include "Shape.h"
#include "Diamond.h"
#include "Array.h"

int main() {
    cout << "===== Q1 & Q3 =====" << endl;
    Employee* e = new Manager("Harshit", 50000, 10000);
    e->calSalary();

    Manager* m = dynamic_cast<Manager*>(e);
    if (m) {
        cout << "Manager detected" << endl;
        m->Bonus();
    }
    delete e;

    cout << "\n===== Q2 =====" << endl;
    Shape* s = new Circle(5);
    s->area();
    s->perimeter();

    Circle* c = dynamic_cast<Circle*>(s);
    if (c) c->circumference();
    delete s;

    cout << "\n===== Q4 =====" << endl;
    D d(10, 20, 30);
    d.display();

    cout << "\n===== Q5 =====" << endl;
    int n;
    cout << "Enter size: ";
    cin >> n;

    Array a1(n), a2(n);
    cout << "Enter first array: ";
    a1.input();
    cout << "Enter second array: ";
    a2.input();

    Array a3 = a1 + a2;
    cout << "Sum: ";
    a3.display();

    cout << "a1[2] before = " << a1[2] << endl;
    a1[2] = 100;
    cout << "After update: ";
    a1.display();

    if (a1 == a2) cout << "Arrays same" << endl;
    else cout << "Arrays different" << endl;

    return 0;
}
