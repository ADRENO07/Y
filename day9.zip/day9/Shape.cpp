#include "Shape.h"

Circle::Circle(double radius) : r(radius) {}
void Circle::area() { cout << "Circle Area: " << 3.14 * r * r << endl; }
void Circle::perimeter() { cout << "Circle Perimeter: " << 2 * 3.14 * r << endl; }
void Circle::circumference() { cout << "Circle Circumference: " << 2 * 3.14 * r << endl; }

Square::Square(double s) : side(s) {}
void Square::area() { cout << "Square Area: " << side * side << endl; }
void Square::perimeter() { cout << "Square Perimeter: " << 4 * side << endl; }

Triangle::Triangle(double x, double y, double z) : a(x), b(y), c(z) {}
void Triangle::area() {
    double s = (a + b + c) / 2;
    cout << "Triangle Area: " << sqrt(s * (s - a) * (s - b) * (s - c)) << endl;
}
void Triangle::perimeter() { cout << "Triangle Perimeter: " << a + b + c << endl; }

