#include "Diamond.h"

A::A(int x) : a(x) {}
B::B(int x, int y) : A(x), b(y) {}
C::C(int x, int z) : A(x), c(z) {}
D::D(int x, int y, int z) : A(x), B(x, y), C(x, z) {}
void D::display() {
    cout << "a = " << a << ", b = " << b << ", c = " << c << endl;
}
