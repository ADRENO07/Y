#include "salesperson.h"

SalesPerson::SalesPerson(const char n[], int h, int r, int s, int c)
    : WageEmployee(n,h,r)
{
    sales = s;
    commission = c;
}

void SalesPerson::accept()
{
    WageEmployee::accept();

    cout << "Enter sales and commission: ";
    cin >> sales >> commission;
}

void SalesPerson::display()
{
    WageEmployee::display();

    cout << "Sales: " << sales << endl;
    cout << "Commission: " << commission << endl;
    cout << "Total Salary: " << salary() << endl;
}

double SalesPerson::salary()
{
    return WageEmployee::salary() + (sales * commission);
}
