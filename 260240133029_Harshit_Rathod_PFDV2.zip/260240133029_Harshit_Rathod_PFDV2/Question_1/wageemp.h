#ifndef WAGEEMP_H
#define WAGEEMP_H

#include "employee.h"

class WageEmployee : public Employee
{
private:
    int hrs;
    int rate;

public:
    WageEmployee() = default;
    WageEmployee(const char[], int, int);

    void accept();
    void display();
    double salary();
};

#endif
