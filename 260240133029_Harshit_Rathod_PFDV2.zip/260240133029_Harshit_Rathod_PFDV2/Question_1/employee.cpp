#include "employee.h"

Employee::Employee(const char n[])
{
    emp_id = generateId();
    strcpy(name, n);
}

int Employee::generateId()
{
    static int id = 4562;
    static int jump = 137;

    id = id + jump;
    jump = jump + 53;

    if(id > 9999)
        id = 1000 + (id % 9000);

    return id;
}

void Employee::accept()
{
    emp_id = generateId();
    cout << "Enter name: ";
    cin >> name;
}

void Employee::display()
{
    cout << "ID: " << emp_id << endl;
    cout << "Name: " << name << endl;
}
