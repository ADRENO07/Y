#include "manager.h"

Manager::Manager(const char n[], int a)
    : Employee(n)
{
    allowance = a;
}

void Manager::accept()
{
    Employee::accept();

    cout << "Enter allowance: ";
    cin >> allowance;
}

void Manager::display()
{
    Employee::display();

    cout << "Allowance: " << allowance << endl;
    cout << "Salary: " << salary() << endl;
}

double Manager::salary()
{
    return allowance;
}
