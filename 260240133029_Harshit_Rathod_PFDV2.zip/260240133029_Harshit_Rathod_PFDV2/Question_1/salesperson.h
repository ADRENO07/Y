#ifndef SALESPERSON_H
#define SALESPERSON_H

#include "wageemp.h"

class SalesPerson : public WageEmployee
{
private:
    int sales;
    int commission;

public:
    SalesPerson() = default;
    SalesPerson(const char[], int, int, int, int);

    void accept();
    void display();
    double salary();
};

#endif
