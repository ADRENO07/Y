#include "salesperson.h"
#include "manager.h"

int main()
{
    Employee *eptr = NULL;
    Employee *arr[10];
    int count = 0;
    int choice, i;

    do
    {
        cout << "\n1. Wage Employee";
        cout << "\n2. Sales Person";
        cout << "\n3. Manager";
        cout << "\n4. Display All";
        cout << "\n0. Exit";
        cout << "\nEnter choice: ";
        cin >> choice;

        if(choice == 1)
        {
            eptr = new WageEmployee();
            eptr->accept();
            arr[count++] = eptr;
        }
        else if(choice == 2)
        {
            eptr = new SalesPerson();
            eptr->accept();
            arr[count++] = eptr;
        }
        else if(choice == 3)
        {
            eptr = new Manager();
            eptr->accept();
            arr[count++] = eptr;
        }
        else if(choice == 4)
        {
            for(i = 0; i < count; i++)
            {
                cout << endl;
                arr[i]->display();
            }
        }

    } while(choice != 0);

    return 0;
}
