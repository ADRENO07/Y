#ifndef MANAGER_H
#define MANAGER_H

#include "employee.h"

class Manager : public Employee
{
private:
    int allowance;

public:
    Manager() = default;
    Manager(const char[], int);

    void accept();
    void display();
    double salary();
};

#endif
