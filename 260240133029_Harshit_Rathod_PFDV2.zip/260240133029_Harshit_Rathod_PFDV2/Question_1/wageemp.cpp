#include "wageemp.h"

WageEmployee::WageEmployee(const char n[], int h, int r)
    : Employee(n)
{
    hrs = h;
    rate = r;
}

void WageEmployee::accept()
{
    Employee::accept();

    cout << "Enter hours and rate: ";
    cin >> hrs >> rate;
}

void WageEmployee::display()
{
    Employee::display();

    cout << "Hours: " << hrs << endl;
    cout << "Rate: " << rate << endl;
    cout << "Salary: " << salary() << endl;
}

double WageEmployee::salary()
{
    return hrs * rate;
}
