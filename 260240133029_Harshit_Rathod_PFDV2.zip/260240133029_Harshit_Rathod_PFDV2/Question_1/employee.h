#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>
#include<string.h>
using namespace std;

class Employee
{
private:
    int emp_id;
    char name[20];

public:
    Employee() = default;
    Employee(const char[]);

    virtual void accept();
    virtual void display();

    int generateId();

    virtual double salary() = 0;
};

#endif
