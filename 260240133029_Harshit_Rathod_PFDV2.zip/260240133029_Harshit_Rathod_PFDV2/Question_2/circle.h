#ifndef CIRCLE_H
#define CIRCLE_H

#include "shape.h"

class Circle : public Shape
{
private:
    float radius;

public:
    Circle() = default;
    Circle(float);

    void area();
    void perimeter();
};

#endif
