#include "square.h"

Square::Square(float s)
{
    side = s;
}

void Square::area()
{
    cout << "Area of Square: " << side * side << endl;
}

void Square::perimeter()
{
    cout << "Perimeter of Square: " << 4 * side << endl;
}
