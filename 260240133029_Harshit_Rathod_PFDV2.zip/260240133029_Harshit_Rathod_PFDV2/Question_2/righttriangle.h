#ifndef RIGHTTRIANGLE_H
#define RIGHTTRIANGLE_H

#include "triangle.h"

class RightTriangle : public Triangle
{
public:
    RightTriangle() = default;
    RightTriangle(float, float, float);

    void area();
    void perimeter();
};

#endif
