#ifndef EQUILATERALTRIANGLE_H
#define EQUILATERALTRIANGLE_H

#include "triangle.h"

class EquilateralTriangle : public Triangle
{
public:
    EquilateralTriangle() = default;
    EquilateralTriangle(float);

    void area();
    void perimeter();
};

#endif
