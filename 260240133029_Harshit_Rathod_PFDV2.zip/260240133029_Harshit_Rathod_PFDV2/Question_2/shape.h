#ifndef SHAPE_H
#define SHAPE_H

#include<iostream>
using namespace std;

class Shape
{
public:
    virtual void area() = 0;
    virtual void perimeter() = 0;
};

#endif
