#include "equilateraltriangle.h"

EquilateralTriangle::EquilateralTriangle(float x)
    : Triangle(x, x, x)
{
}

void EquilateralTriangle::area()
{
    cout << "Area of Equilateral Triangle: " << 0.433 * a * a << endl;
}

void EquilateralTriangle::perimeter()
{
    cout << "Perimeter of Equilateral Triangle: " << 3 * a << endl;
}
