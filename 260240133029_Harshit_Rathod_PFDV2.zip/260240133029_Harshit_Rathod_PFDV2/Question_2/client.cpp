#include "circle.h"
#include "square.h"
#include "righttriangle.h"
#include "equilateraltriangle.h"

int main()
{
    Shape *sptr = NULL;
    int choice;
    float x, y, z;

    do
    {
        cout << "\n1. Circle";
        cout << "\n2. Square";
        cout << "\n3. Right Triangle";
        cout << "\n4. Equilateral Triangle";
        cout << "\n0. Exit";
        cout << "\nEnter choice: ";
        cin >> choice;

        if(choice == 1)
        {
            cout << "Enter radius: ";
            cin >> x;

            sptr = new Circle(x);
        }
        else if(choice == 2)
        {
            cout << "Enter side: ";
            cin >> x;

            sptr = new Square(x);
        }
        else if(choice == 3)
        {
            cout << "Enter base, height, hypotenuse: ";
            cin >> x >> y >> z;

            sptr = new RightTriangle(x, y, z);
        }
        else if(choice == 4)
        {
            cout << "Enter side: ";
            cin >> x;

            sptr = new EquilateralTriangle(x);
        }
        else
        {
            break;
        }

        sptr->area();
        sptr->perimeter();

        delete sptr;

    } while(choice != 0);

    return 0;
}
