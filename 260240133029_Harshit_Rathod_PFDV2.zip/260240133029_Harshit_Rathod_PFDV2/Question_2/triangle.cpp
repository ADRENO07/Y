#include "triangle.h"

Triangle::Triangle(float x, float y, float z)
{
    a = x;
    b = y;
    c = z;
}

void Triangle::area()
{
    cout << "Area depends on triangle type" << endl;
}

void Triangle::perimeter()
{
    cout << "Perimeter of Triangle: " << a + b + c << endl;
}
