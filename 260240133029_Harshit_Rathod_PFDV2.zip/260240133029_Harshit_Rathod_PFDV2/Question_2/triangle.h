#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "shape.h"

class Triangle : public Shape
{
protected:
    float a, b, c;

public:
    Triangle() = default;
    Triangle(float, float, float);

    virtual void area();
    virtual void perimeter();
};

#endif
