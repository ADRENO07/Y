#include "righttriangle.h"

RightTriangle::RightTriangle(float x, float y, float z)
    : Triangle(x, y, z)
{
}

void RightTriangle::area()
{
    cout << "Area of Right Triangle: " << 0.5 * a * b << endl;
}

void RightTriangle::perimeter()
{
    cout << "Perimeter of Right Triangle: " << a + b + c << endl;
}
