#include "circle.h"

Circle::Circle(float r)
{
    radius = r;
}

void Circle::area()
{
    cout << "Area of Circle: " << 3.14 * radius * radius << endl;
}

void Circle::perimeter()
{
    cout << "Circumference of Circle: " << 2 * 3.14 * radius << endl;
}
