#ifndef SQUARE_H
#define SQUARE_H

#include "shape.h"

class Square : public Shape
{
private:
    float side;

public:
    Square() = default;
    Square(float);

    void area();
    void perimeter();
};

#endif
